<?php
session_start();
  require_once '../classes/Database.php';
 $username = $_POST['username'];
 $password = $_POST['password'];
 $confirm_password = $_POST['confirm_password'];
 $email = $_POST['email'];
 $tdate=date('Y-m-d H:i:s');
 $db = new Database();

 if($username=="")
 {
     echo "Please Enter Your Username";
     exit();
 }

 if($password=="")
 {
     echo "Please Enter Your Password";
     exit();
 }

 if($email=="")
 {
     echo "Please Enter Your Email";
     exit();
 }


 if($password!=$confirm_password)
 {
     echo 'Password And Confirm Password Do Not Match';
     exit();
 }

 $getRow = $db->getRow("SELECT * FROM users WHERE username =?", [$username]);
if($getRow)
{
    echo 'This Username Already Exist';
    exist();
}


  //get Row



  //$kooo = 'test123';
  $pass = password_hash($password ,PASSWORD_DEFAULT);

  $insertRow = $db->insertRow("INSERT INTO users(username,password,email,date) VALUES (?,?,?,?)", [$username,$pass,$email,$tdate]);
  if($insertRow)
  {
      echo 'Rgistered Successfully';
      $_SESSION['username']=$username;
      header("Location: ../index.php");
  }

?>