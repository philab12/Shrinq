<?php
session_start();
require_once '../classes/Database.php';
$username = $_POST['username'];
$password = $_POST['password'];

$db = new Database();


$getRow = $db->getRow("SELECT * FROM users WHERE username =?", [$username]);
if(!$getRow)
{
    echo 'This Username Or Password Is Wrong';
    exist();
}
else
{
    $pass = $getRow['password'];
    $usrname = $getRow['username'];
    $id = $getRow['id'];
}


$login= password_verify($password,$pass);
if($login)
{
    $_SESSION['username']=$usrname;
    $_SESSION['username_id']=$id;

      header("Location: ../index.php");
}
?>