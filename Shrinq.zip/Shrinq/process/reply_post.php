<?php
session_start();
$reply = $_POST['reply'];
$username_id =  $_SESSION['username_id'];
$tdate=date('Y-m-d H:i:s');

if($reply=="")
{
    echo "Please make sure you enter reply";
    exit();
}

$db = new Database();

$insertRow = $db->insertRow("INSERT INTO reply_post(reply,post,user_id,date) VALUES (?,?,?,?)", [$reply,"",$username_id,$tdate]);
if($insertRow)
{
    echo 'Reply Successfully';
 
}
?>